def get_supported_networks():
    return ["ethereum", "arbitrum", "optimism", "base"]
