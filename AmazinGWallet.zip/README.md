# AmazinGWallet

Multi-chain crypto wallet backend with support for swaps and L2 chains like Arbitrum, Optimism, Base.
