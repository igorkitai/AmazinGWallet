RPC_URLS = {
    "ethereum": "https://mainnet.infura.io/v3/YOUR_KEY",
    "arbitrum": "https://arb1.arbitrum.io/rpc",
    "optimism": "https://mainnet.optimism.io",
    "base": "https://mainnet.base.org"
}
